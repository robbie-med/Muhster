---
name: Bug
description: Report a defect
title: "[Bug]: "
labels: ["bug"]
body:
  - type: textarea
    id: description
    attributes:
      label: Description
      description: What is wrong?
    validations:
      required: true
  - type: textarea
    id: steps
    attributes:
      label: Steps to reproduce
      description: Exact steps.
    validations:
      required: true
  - type: textarea
    id: expected
    attributes:
      label: Expected behavior
    validations:
      required: true
  - type: textarea
    id: security
    attributes:
      label: Security impact
      description: Note if this affects sensitive data, permissions, audit, or encryption.
    validations:
      required: false
