---
name: Feature
description: Build a MUSTER feature
title: "[Feature]: "
labels: ["feature"]
body:
  - type: textarea
    id: purpose
    attributes:
      label: Purpose
      description: What operational problem does this solve?
    validations:
      required: true
  - type: textarea
    id: scope
    attributes:
      label: Scope
      description: What should be included?
    validations:
      required: true
  - type: textarea
    id: acceptance
    attributes:
      label: Acceptance criteria
      description: Use explicit, testable criteria.
    validations:
      required: true
  - type: textarea
    id: security
    attributes:
      label: Security and privacy considerations
      description: Roles, sensitivity, audit, encryption, and local-hosting concerns.
    validations:
      required: true
