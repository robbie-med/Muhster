# Copilot Instructions for MUSTER

MUSTER is not a generic charity CRM. It is a locally hosted, desktop-first operational care-coordination and readiness system for church deacons.

## Core product doctrine

Deacons operate as disciplined coordinators of household care, commitments, resources, needs, threats, property, preparedness, and follow-through.

Favor operational execution over generic dashboards.

## Coding rules

Use TypeScript.
Use React.
Keep modules small.
Separate UI, domain logic, storage, crypto/security, and sync concerns.
Use strong typing for every entity.
Do not add external SaaS dependencies unless explicitly approved.
Keep local hosting as the default.
Do not put sensitive content in logs.
Do not bypass permission helpers.
Do not weaken encryption boundaries for convenience.

## UI rules

Desktop command center first.
Dense tables are acceptable.
Use status chips, filters, and operational actions.
Avoid social-feed patterns.
Avoid sentimental nonprofit language.
Family and field apps must expose only what is needed.

## Security rules

Assume the app stores sensitive household, benevolence, disaster, and security information.
Every sensitive access should be auditable.
E2EE is required for household-to-deacon communication.
Local server should not read encrypted message content.
SMS and push notifications must not contain sensitive details.

## Acceptance standard

Each feature should answer one or more of these:

Who is responsible?
What is needed?
What resource is available?
What was committed?
What was done?
What is blocked?
What must happen next?
Who must be escalated to elders?
